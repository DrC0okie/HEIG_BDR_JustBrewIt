Ordre d'exécution des fichiers .sql:
schema => requests => import => triggers => views