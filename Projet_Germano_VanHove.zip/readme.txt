Déploiement:

1) Ouvrir un terminal à l'emplacement du fichier docker-compose (application/docker-compose.yml)
	la base de donnée s'initialise avec le fichier init.sql (rien à faire, initialisation automatique)

2) Executer la commande "docker-compose up --build"

3) Depuis un browser se connecter à localhost

4) Pour voir toutes les pages du site, se logger avec:
		 utilisateur: 	admin
		 mot de passe: 	admin