<?php include './header.php';?>
    <main class="p-6">
      <h2 class="text-2xl font-medium mb-4">Bienvenue!</h2>
      <img src="images/landingPage.jpg">
    </main>
<?php include './footer.php';?>