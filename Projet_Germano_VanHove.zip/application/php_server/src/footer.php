    <footer class="bg-white p-6">
      <p class="text-center text-gray-600">Copyright ©Just Brew It</p>
    </footer>
  </body>
</html>